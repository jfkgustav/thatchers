
<div class="container h-1/3 flex justify-center items-center">
  <h1 class="font-extrabold -mt-10 text-5xl text-white drop-shadow-xl">THATCHERS</h1>
</div>

