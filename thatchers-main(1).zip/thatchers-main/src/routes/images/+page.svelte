<script>
  import pistoler from "$lib/assets/pistoler.png";
  import sittin from "$lib/assets/sittin.png";
  import stocks from "$lib/assets/stocks.png";
  import verysmol from "$lib/assets/verysmol.png";
  import glajjor from "$lib/assets/glajjor.png";
  import bank from "$lib/assets/bank.png";
  import verket from "$lib/assets/verket.jpg";
  import midsommar from "$lib/assets/midsommar.jpg";
  import linked from "$lib/assets/linked.jpg";
  import klassiker from "$lib/assets/klassiker.jpg";
</script>


  <div class="w-full h-screen container overflow-y-scroll grid grid-cols-3 gap-10 p-10">
  
    
    <img src={bank}>
    <img src={sittin}>
    <img src={midsommar}>
    <img src={verket}>
    <img src={klassiker}>
    <img src={glajjor}>
    <img src={verysmol}>
    <img src={linked}>
    <img src={pistoler}>

  </div>
