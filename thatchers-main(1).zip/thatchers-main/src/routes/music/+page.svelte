


  <div class="mx-auto w-5/6 h-5/6 pb-5 overflow-y-scroll rounded-lg">
    <h1 class="p-3 font-bold text-xl text-white text-center">Musik vi släppt</h1>
    <div class="container">
    <iframe class="pt-5" style="border-radius:12px" src="https://open.spotify.com/embed/track/1gpz6EGIlscOTLwOb69YBu?utm_source=generator&theme=0" width="100%" height="352" frameBorder="0" allowfullscreen="" allow="autoplay; clipboard-write; encrypted-media; fullscreen; picture-in-picture" loading="lazy"></iframe>

    <iframe class="pt-10 -mt-20" style="border-radius:12px" src="https://open.spotify.com/embed/track/3mNN97pi8xIpyL7HeUDiVS?utm_source=generator" width="100%" height="352" frameBorder="0" allowfullscreen="" allow="autoplay; clipboard-write; encrypted-media; fullscreen; picture-in-picture" loading="lazy"></iframe>

    <iframe class="-mt-10" style="border-radius:12px" src="https://open.spotify.com/embed/album/4mPJo9Z8TjbawbUluA4uPp?utm_source=generator" width="100%" height="352" frameBorder="0" allowfullscreen="" allow="autoplay; clipboard-write; encrypted-media; fullscreen; picture-in-picture" loading="lazy"></iframe>
  
    <iframe class="mt-10" style="border-radius:12px" src="https://open.spotify.com/embed/album/6VN0JzrgGOuiMCCjDolemS?utm_source=generator" width="100%" height="352" frameBorder="0" allowfullscreen="" allow="autoplay; clipboard-write; encrypted-media; fullscreen; picture-in-picture" loading="lazy"></iframe>
  
    <iframe class="mt-10" style="border-radius:12px" src="https://open.spotify.com/embed/album/0dcaJ1kod8VIndjB3h8AHt?utm_source=generator" width="100%" height="352" frameBorder="0" allowfullscreen="" allow="autoplay; clipboard-write; encrypted-media; fullscreen; picture-in-picture" loading="lazy"></iframe>

  </div>
  </div>

  <p class="p-3 font-bold text-xl text-gray-400 hidden text-center bg-gray-50 w-fit mx-auto"> Psst! Vill du höra någon av våra demos? Skicka ett mejl till oss @ thatchersavar@gmail.com </p>
