<script>
  import pistoler from "$lib/assets/pistoler.png";
  import sittin from "$lib/assets/sittin.png";
  import stocks from "$lib/assets/stocks.png";
  import verysmol from "$lib/assets/verysmol.png";
  import glajjor from "$lib/assets/glajjor.png";
  import bank from "$lib/assets/bank.png";
</script>


<div class="p-4">
  <h1 style="color: white;">THATCHERS</h1>


<div>
  <div>
  <iframe class="pt-10" style="border-radius:12px" src="https://open.spotify.com/embed/track/1gpz6EGIlscOTLwOb69YBu?utm_source=generator&theme=0" width="100%" height="352" frameBorder="0" allowfullscreen="" allow="autoplay; clipboard-write; encrypted-media; fullscreen; picture-in-picture" loading="lazy"></iframe>

  <iframe class="pt-10 -mt-20" style="border-radius:12px" src="https://open.spotify.com/embed/track/3mNN97pi8xIpyL7HeUDiVS?utm_source=generator" width="100%" height="352" frameBorder="0" allowfullscreen="" allow="autoplay; clipboard-write; encrypted-media; fullscreen; picture-in-picture" loading="lazy"></iframe>

  <iframe class="-mt-10" style="border-radius:12px" src="https://open.spotify.com/embed/album/4mPJo9Z8TjbawbUluA4uPp?utm_source=generator" width="100%" height="352" frameBorder="0" allowfullscreen="" allow="autoplay; clipboard-write; encrypted-media; fullscreen; picture-in-picture" loading="lazy"></iframe>
  
  </div>
</div>

<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>

<hr>
<br>


  <div>
  
    <img src={pistoler}>
    <img src={bank}>
    <img src={stocks}>
    <img src={verysmol}>
    <img src={glajjor}>
    <img src={sittin}>

  </div>

</div>