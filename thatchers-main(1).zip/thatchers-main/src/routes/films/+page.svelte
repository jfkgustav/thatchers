

  <div class="mx-auto w-5/6 h-5/6 pb-5 overflow-y-scroll rounded-lg">
    <h1 class="p-3 font-bold text-xl text-black text-center bg-gray-50 w-fit mx-auto">Filmer från spelningar</h1>
    <div class="container ">
      <br>
      <iframe width="1143" height="690" class="w-5/6 mx-auto" src="https://drive.google.com/file/d/1fd-TjdyiOkuAWrlXFV15pq189PwncF9l/preview" title="Thatchers live på balder" allow="autoplay"></iframe>
      <br>
      <iframe width="1143" height="690" class="w-5/6 mx-auto" src="https://www.youtube.com/embed/3HTQnGe9aCY?list=PLRzc2PHbZ8D3YZl9j_hRPsQUEYcvZlVg-" title="Umeå Live - Thatchers &quot;Nocco&quot;" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen></iframe>
      <br>
      <iframe width="1143" height="643" class="w-5/6 mx-auto" src="https://www.youtube.com/embed/fIRaymarEdk?list=PLRzc2PHbZ8D3YZl9j_hRPsQUEYcvZlVg-" title="Umeå Live - Thatchers &quot;Gården är tom&quot;" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen></iframe>

    </div>
  </div>

  <a href="https://www.youtube.com/@thatchers7313"><p class="p-3 font-bold text-xl text-black text-center bg-gray-50 w-fit mx-auto"> Besök också vår youtubekanal! </p></a>
